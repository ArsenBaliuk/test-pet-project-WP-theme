<?php

///////////////////////////////////////////////////////////////////////////////////////////////////


add_action( 'admin_enqueue_scripts', 'true_include_myuploadscript' );

function true_include_myuploadscript( $hook ) {
    wp_enqueue_script('jquery');

    if ( ! did_action( 'wp_enqueue_media' ) ) {
        wp_enqueue_media();
    }

    wp_enqueue_script( 'myuploadscript', get_stylesheet_directory_uri() . '/js/scripts.js', array('jquery'), null, false );
}
function extra_media_field_box_func( $args ) {

    $value = get_option( $args[ 'name' ] );

    $value = $args[ 'value' ];
    $default = get_stylesheet_directory_uri() . '/images/placeholder.svg';

    if( $value && ( $image_attributes = wp_get_attachment_image_src( $value, array( 150, 110 ) ) ) ) {
        $src = $image_attributes[0];
    } else {
        $src = $default;
    }
    echo '
	<div>
		<img data-src="' . $default . '" src="' . $src . '" width="150" />
		<div>
			<input type="hidden" name="' . $args[ 'name' ] . '" id="' . $args[ 'name' ] . '" value="' . $value . '" />
			<button type="submit" class="upload_image_button button">Завантажити</button>
			<button type="submit" class="remove_image_button button">×</button>
		</div>
	</div>
	';
}

add_action( 'add_meta_boxes', 'my_extra_media_field', 1 );

function my_extra_media_field() {
    add_meta_box( 'truediv', 'Зображення до оголошення', 'print_media_field', 'rw_olx', 'normal', 'high' );
}

function print_media_field( $post ) {
    if( function_exists( 'extra_media_field_box_func' ) ) {
        extra_media_field_box_func( array(
            'name' => 'uploader_custom',
            'value' => get_post_meta( $post->ID, 'uploader_custom', true ),
        ) );
    }
}

add_action('save_post', 'save_media_field');
function save_media_field( $post_id ) {

    if( isset( $_POST[ 'uploader_custom' ] ) ) {
        update_post_meta( $post_id, 'uploader_custom', absint( $_POST[ 'uploader_custom' ] ) );
    }
    return $post_id;

}


///////////////////////////////////////////////////////////////////////////////////////////////////

add_action('add_meta_boxes', 'my_extra_field', 1);

function my_extra_field() {
    add_meta_box( 'extra_field', 'Додаткова інформація', 'extra_field_box_func', 'rw_olx', 'normal', 'high'  );

}
function extra_field_box_func( $post ){
?>
    <p><label>Заголовок оголошення: <input type="text" name="extra[title]" value="<?php echo get_post_meta($post->ID, 'title', 1); ?>" style="width:50%" /></label></p>

    <p><label>Email автора: <input type="text" name="extra[email]" value="<?php echo get_post_meta($post->ID, 'email', 1); ?>" style="width:50%" /></label></p>
<?php
}
add_action( 'save_post', 'my_extra_field_update', 0 );

function my_extra_field_update( $post_id ){
    // базова преревірка
    if (
        empty( $_POST['extra'] )
//        || ! wp_verify_nonce( $_POST['extra_fields_nonce'], __FILE__ )
        || wp_is_post_autosave( $post_id )
        || wp_is_post_revision( $post_id )
    )
        return false;

    // Зберегти нові/видалити старі дані
    $_POST['extra'] = array_map( 'sanitize_text_field', $_POST['extra'] ); // очищаємо краї від пропусків
    foreach( $_POST['extra'] as $key => $value ){
        if( empty($value) ){
            delete_post_meta( $post_id, $key ); // видаляємо поле, якщо значення пусте
            continue;
        }
        update_post_meta( $post_id, $key, $value ); // add_post_meta() працює автоматично
    }

    return $post_id;
}
///////////////////////////////////////////////////////////////////////////////////////////////////



// Debug mod

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);


// Running theme setup functions, such as enabling support for the title tag and so on

add_action('after_setup_theme', 'theme_setup');

function theme_setup() {

    add_theme_support('title-tag');

    // Adding for translation function

    __('Enter your city', 'pet_project');

}


/*
* Add languages setup
*/

function pet_project_one_setup(){

    load_theme_textdomain('pet_project', get_template_directory() . '/languages');

}

add_action( 'after_setup_theme', 'pet_project_one_setup' );


// Add thumbnails to post

add_theme_support( 'post-thumbnails' );


// Add scripts and styles

add_action('wp_enqueue_scripts', 'pet_project_styles');

function pet_project_styles() {

    wp_enqueue_style( 'pet_project-style', get_template_directory_uri() . '/css/styles.css', array(), '1.0.4' );

    wp_enqueue_style( 'pet_project-media-style', get_template_directory_uri() . '/css/media.css', array(), '1.0.0' );

}

add_action('wp_enqueue_scripts', 'pet_project_scripts');

function pet_project_scripts() {

    wp_enqueue_script('pet_project-scripts', get_template_directory_uri() . '/js/scripts.js', array(), '1.0.6');

    wp_localize_script('pet_project_scripts', 'vd_data', []);

    wp_localize_script('pet_project-scripts', 'vd_data', ['ajaxurl' => admin_url('admin-ajax.php')]);

}


// Register  navigation menus

add_action( 'after_setup_theme', function(){
    register_nav_menus( [
        'headerMenu' => 'Header Menu',
        'footerMenu' => 'Footer Menu',
    ] );
} );


// Upload SVG

add_filter( 'upload_mimes', 'svg_upload_allow' );

function svg_upload_allow( $mimes ) {
    $mimes['svg']  = 'image/svg+xml';
    return $mimes;
}

add_filter( 'wp_check_filetype_and_ext', 'fix_svg_mime_type', 10, 5 );

function fix_svg_mime_type( $data, $file, $filename, $mimes, $real_mime = '' ){
    if( version_compare( $GLOBALS['wp_version'], '5.1.0', '>=' ) )
        $dosvg = in_array( $real_mime, [ 'image/svg', 'image/svg+xml' ] );
    else
        $dosvg = ( '.svg' === strtolower( substr($filename, -4) ) );
    if( $dosvg ){
        if( current_user_can('manage_options') ){
            $data['ext']  = 'svg';
            $data['type'] = 'image/svg+xml';
        }
        else {
            $data['ext'] = $type_and_ext['type'] = false;
        }
    }
    return $data;
}


// Admin CSS

add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
    echo '<style>
    #meta-box-notification {
    display: none;
    }
  </style>';
}


// Include files

include 'frontend-create-posts/frontend-create-posts.php';

// Register  site settings

function register_options_pages($settings_pages) {

    $settings_pages[] = array(
        'id'          => 'site-settings-main',
        'option_name' => 'site_settings_main',
        'menu_title'  => 'Site Settings',
        'icon_url'    => 'dashicons-edit',
        'style'       => 'boxes',
        'columns'     => 1,
        'position'    => 68,
    );

    return $settings_pages;

}

// Hide admin bar for subscribers

add_action('set_current_user', 'cc_hide_admin_bar');

function cc_hide_admin_bar() {

    if (!current_user_can('edit_posts')) {

        show_admin_bar(false);

    }
}



// Remove filter from Metaboxes

remove_filter ('the_content', 'wpautop');


/*
* Creating a function to create our CPT
*/

function custom_post_type() {

// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => 'Publications',
        'singular_name'       => 'Publication',
        'menu_name'           => 'Publications',
        'all_items'           => 'All Publication',
        'view_item'           => 'View Publication',
        'add_new_item'        => 'Add New Publication',
        'add_new'             => 'Add New',
        'edit_item'           => 'Edit Publication',
        'update_item'         => 'Update Publication',
        'search_items'        => 'Search Publication',
        'not_found'           => 'Not Found',
        'not_found_in_trash'  => 'Not found in Trash',
    );



// Set other options for Custom Post Type

    $args = array(
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'revisions'),
        // You can associate this CPT with a taxonomy or custom taxonomy.
//        'taxonomies'          => array( 'topics', 'employees_served'),
        'public'              => true,
        'menu_icon' => 'dashicons-universal-access-alt',
        'has_archive'         => true,
        'revision' => true,
    );

    // Registering your Custom Post Type
    register_post_type( 'rw_olx', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not
* unnecessarily executed.
*/

add_action( 'init', 'custom_post_type', 0 );


?>