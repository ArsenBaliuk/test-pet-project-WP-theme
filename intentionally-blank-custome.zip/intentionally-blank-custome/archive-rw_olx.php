<?php
/**
 * Archive Template
 */
get_header(); ?>

<?php
$page_id = get_the_ID();

$args = array(
    'post_type' => 'rw_olx',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'order' => 'ASC',
    'orderby' => 'menu_order'
);

$query = new WP_Query( $args );

?>

    <section class="publication-top-section">
        <div class="ab-container">
            <div class="row">
                <div class="col-12 publications-text-col">
                    <div class="publications-title">
                        Оголошення користувачів сервісу
                    </div>
                    <div class="publications-description">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto distinctio doloremque eius error harum, ipsum itaque iure odio officiis placeat praesentium quas, qui soluta tempore totam veritatis vitae. Adipisci, non!</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section publication-archive-section">

        <div class="ab-container">

            <div class="row">

                <?php if($query->have_posts()): ?>

                    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                        <?php
                        $post_id = get_the_ID();
                        $image_id = get_post_meta($post_id, 'uploader_custom', true);
                        $img_url = wp_get_attachment_image_src($image_id, 'full');
                        $thumbnail_image = wp_get_attachment_url( get_post_thumbnail_id($post_id), 'full' );
                        $title = get_post_meta($post_id, 'title', true);
                        ?>

                        <div class="col-12 col-md-6 col-xl-3 single-publication-card">
                            <a href="<?php echo get_permalink(); ?>" target="_blank">
                                <div class="coach-card-text">
                                    <div class="publication-picture">
                                        <?php
                                        if (!empty($image_id)) {
                                            echo '<img src="' . $img_url[0] . '" alt="" />';
                                        } else if (!empty($thumbnail_image)){
                                            echo '<img src="' . $thumbnail_image . '" alt="" />';
                                        } else {
                                            echo 'Фото не завантажено.';
                                        }
                                        ?>
                                    </div>
                                    <div class="post-title"><?php echo $title; ?></div>
                                </div>
                            </a>
                        </div>

                    <?php endwhile; ?>

                <?php endif; ?>

            </div>
        </div>
    </section>

<?php get_footer(); ?>