<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

    <header class="main-header">

        <div class="ab-container">

            <div class="row">
                <div class="col-4 col-md-2">
                    <a class="site-title" href="<?php echo get_site_url(); ?>">
                        Site title
                    </a>
                </div>
                <div class="col-8 col-md-10">
                    <div class="nav-desktop-wrap">
                        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'headerMenu',
                            'container_class' => '',
                            'container' => '',
                            'menu_class' => 'nav-list',
                        ));
                        ?>
                    </div>

                    <div class="menu-head">
                        <div class="head-menu-trigger">
                            <div class="open-svg btn-svg">
                                <svg width="30" height="21" viewBox="0 0 30 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <line x1="0.5" y1="0.5" x2="29.5" y2="0.5" stroke="black" stroke-linecap="round"/>
                                    <line x1="0.5" y1="10.5" x2="29.5" y2="10.5" stroke="black" stroke-linecap="round"/>
                                    <line x1="0.5" y1="20.5" x2="29.5" y2="20.5" stroke="black" stroke-linecap="round"/>
                                </svg>
                            </div>
                            <div class="close-svg btn-svg hidden-element">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.89069 1.49072L22.3999 22" stroke="black" stroke-width="2" stroke-linecap="round"/>
                                    <path d="M1.64984 22L22.1591 1.49074" stroke="black" stroke-width="2" stroke-linecap="round"/>
                                </svg>
                            </div>
                        </div>
                        <div class="nav-mobile-wrap">
                            <?php
                            wp_nav_menu( array(
                                'theme_location' => 'headerMenu',
                                'container_class' => '',
                                'container' => '',
                                'menu_class' => 'nav-list',
                            ));
                            ?>
                        </div>

                    </div>
                   
                </div>
            </div>

        </div>
    </header>

    <script>
        jQuery('.btn-svg').on('click',function() {
            jQuery('.btn-svg').toggleClass('hidden-element');
            jQuery('.nav-mobile-wrap').toggleClass('active');
        });
    </script>

    <main>