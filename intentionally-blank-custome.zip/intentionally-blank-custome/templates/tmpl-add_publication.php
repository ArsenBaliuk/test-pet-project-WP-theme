<?php /* Template Name: Add publication page */ ?>

<?php get_header(); ?>

    <section class="add-publication-section">
        <div class="ab-container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <?php echo do_shortcode("[afcp_form]"); ?>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>