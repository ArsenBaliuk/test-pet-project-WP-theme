<?php /* Template Name: Home page */ ?>

<?php get_header(); ?>

<?php
$post_id = get_the_ID();
$title = get_post_meta($post_id, 'title_top_section', true);
$description = get_post_meta($post_id, 'description_top_section', true);

$about_title = get_post_meta($post_id, 'about_project_title', true);
$about_description = get_post_meta($post_id, 'about_project_description', true);
?>

    <section class="home-page-section start-home-section">
        <div class="ab-container">
            <div class="row">
                <div class="col-12 col-md-7">
                    <div class="general-title"><?php echo $title; ?></div>
                    <div class="general-description"><?php echo $description; ?></div>
                </div>
            </div>
        </div>
    </section>

    <section class="home-page-section about-project">
        <div class="ab-container">
            <div class="row">
                <div class="col-12 col-md-7">
                    <div class="general-title"><?php echo $about_title; ?></div>
                    <div class="general-description"><?php echo $about_description; ?></div>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>