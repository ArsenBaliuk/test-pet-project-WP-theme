<?php /* Template Name: Home page */ ?>

<?php get_header(); ?>

    <section class="home-page-section start-home-section">
        <div class="ab-container">
            <div class="row">
                <div class="col-12 col-md-7">
                    <div class="general-title">Тестовий проект для створення оголошень</div>
                    <div class="general-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda cum deleniti laboriosam laborum libero, omnis porro quaerat sed! Dolore est harum impedit magnam, maiores odio possimus quae ratione totam veritatis!</div>
                </div>
            </div>
        </div>
    </section>

    <section class="home-page-section about-project">
        <div class="ab-container">
            <div class="row">
                <div class="col-12 col-md-7">
                    <div class="general-title">Про проект:</div>
                    <div class="general-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda cum deleniti laboriosam laborum libero, omnis porro quaerat sed! Dolore est harum impedit magnam, maiores odio possimus quae ratione totam veritatis!</div>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>