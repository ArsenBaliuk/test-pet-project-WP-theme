<?php get_header(); ?>
<!---->
<?php
$post_id = get_the_ID();

$image_id = get_post_meta($post_id, 'uploader_custom', true);
$img_url = wp_get_attachment_image_src($image_id, 'full');
$thumbnail_image = wp_get_attachment_url( get_post_thumbnail_id($post_id), 'full' );
$title = get_post_meta($post_id, 'title', true);
?>

    <section class="single-publication-post single-publication-image">

        <div class="ab-container">

            <div class="row">

                <div class="col-12 publication-col">

                    <div class="publication-picture">

                        <?php
                        if (!empty($image_id)) {
                            echo '<img src="' . $img_url[0] . '" alt="" />';
                        } else if (!empty($thumbnail_image)){
                            echo '<img src="' . $thumbnail_image . '" alt="" />';
                        } else {
                            echo 'Фото не завантажено.';
                        }
                        ?>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <section class="single-publication-post single-publication-text">
        <div class="ab-container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="publication-title">
                        <h2><?php echo $title; ?></h2>
                    </div>
                    <div class="publication-description">
                        <?php echo the_content(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>