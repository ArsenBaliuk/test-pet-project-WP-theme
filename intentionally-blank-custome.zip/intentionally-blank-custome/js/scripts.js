jQuery(function(jQuery){
    /*
     * дія при нажатті кнопки завантаження зображення
     */
    jQuery('.upload_image_button').click(function( event ){

        event.preventDefault();

        const button = jQuery(this);

        const customUploader = wp.media({
            title: 'Оберіть одне зображення',
            library : {
                // uploadedTo : wp.media.view.settings.post.id,
                type : 'image'
            },
            button: {
                text: 'Обрати зображення'
            },
            multiple: false
        });

        // подія вибору зобрження
        customUploader.on('select', function() {

            const image = customUploader.state().get('selection').first().toJSON();

            button.parent().prev().attr( 'src', image.url );
            button.prev().val( image.id );

        });

        // відкриття модального вікна з вибором зображення
        customUploader.open();
    });
    /*
     * видаляємо значення поля (value)
     */
    jQuery('.remove_image_button').click(function( event){

        event.preventDefault();

        if ( true == confirm( "Видалити зображення?" ) ) {
            const src = jQuery(this).parent().prev().data('src');
            jQuery(this).parent().prev().attr('src', src);
            jQuery(this).prev().prev().val('');
        }
    });
});