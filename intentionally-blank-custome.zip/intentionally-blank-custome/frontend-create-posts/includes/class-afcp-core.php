<?php

class AFCP_Core {

	private static $instanse;


	public function __construct() {

		$this->hooks();

		$this->includes();
	}


	public function hooks() {

		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ] );

//        add_action( 'init', [ $this, 'register_cpt_event' ] );
//        add_action( 'init', [ $this, 'register_tax_topics' ] );
//        add_action( 'init', [ $this, 'register_tax_hashtags' ] );
	}


	public function includes() {

		require_once AFCP_DIR . 'includes/class-afcp-shortcode.php';
		new AFCP_Shortcode();

		require_once AFCP_DIR . 'includes/class-afcp-ajax.php';
		new AFCP_Ajax();

	}


	public function enqueue() {

		wp_register_style(
			'afcp-styles',
            get_stylesheet_directory_uri()  . '/frontend-create-posts/assets/afcp-style.css',
			[],
			filemtime( AFCP_DIR . 'assets/afcp-style.css' )
		);

		wp_enqueue_style( 'afcp-styles' );
        
        
		wp_register_script(
			'afcp-script-ajax',
            get_stylesheet_directory_uri()  . '/frontend-create-posts/assets/afcp-ajax.js',
			[ 'jquery' ],
			filemtime( AFCP_DIR . 'assets/afcp-ajax.js' ),
			true
		);

		wp_localize_script(
			'afcp-script-ajax',
			'afcp_ajax',
			[
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'afcp-ajax-nonce' ),
			]
		);

	}

	public static function instance() {

		if ( is_null( self::$instanse ) ) {
			self::$instanse = new self();

		}

		return self::$instanse;
	}
}