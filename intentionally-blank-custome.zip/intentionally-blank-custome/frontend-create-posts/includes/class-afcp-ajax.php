<?php

class AFCP_Ajax {

	public function __construct() {

		add_action( 'wp_ajax_created_publication', [ $this, 'callback' ] );
		add_action( 'wp_ajax_nopriv_created_publication', [ $this, 'callback' ] );
	}


	public function callback() {


		check_ajax_referer( 'afcp-ajax-nonce', 'nonce' );

		$this->validation();

		$publication_data = [
			'post_type'    => 'rw_olx',
			'post_status'  => 'publish',
			'post_title'   => sanitize_text_field( 'Оголошення' ),
			'meta_input'   => [
                'title'            => sanitize_text_field( $_POST['publication_title'] ),
                'email'            => sanitize_text_field( $_POST['email'] ),
			],
		];

		$post_id = wp_insert_post( $publication_data );

		$this->upload_thumbnail( $post_id );

//		$this->set_term( $post_id, $publication_data['tax_input'] );

		$this->success( 'Оголошення `' . $post_id . '` успішно створено' );

		wp_die();
	}


	public function upload_thumbnail( $post_id ) {

		if ( empty( $_FILES ) ) {
			return;
		}

		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
		require_once( ABSPATH . 'wp-admin/includes/media.php' );

		add_filter(
			'upload_mimes',
			function ( $mimes ) {

				return [
					'jpg|jpeg|jpe' => 'image/jpeg',
					'png'          => 'image/png',
				];
			}
		);

		$attachment_id = media_handle_upload( 'uploader_custom', $post_id );

		if ( is_wp_error( $attachment_id ) ) {
			$response_message = 'Помилка завантаження файлу `' . $_FILES['uploader_custom']['name'] . '`: ' . 'Завантажити дозволено виключно зображення!';
			$this->error( $response_message );
		}
		set_post_thumbnail( $post_id, $attachment_id );

        media_handle_upload( $attachment_id, $post_id, 'uploader_custom' );

    }

	public function validation() {

		$error = [];

		$required = [
			'publication_title'    => 'Це обовʼязкове поле. Вкажіть заголовок оголошення',
            'email'                => 'Це обовʼязкове поле. Вкажіть ваш email',
//			'uploader_custom'      => 'Це обовʼязкове поле. Завантажте зображення до оголошення',
        ];

		foreach ( $required as $key => $item ) {

			if ( empty( $_POST[ $key ] ) || ! isset( $_POST[ $key ] ) ) {
				$error[ $key ] = $item;
			}
		}

		if ( $error ) {
			$this->error( $error );
		}
	}

	public function success( $message ) {

		wp_send_json_success(
			[
				'response' => 'SUCCESS',
				'message'  => $message,
			]
		);
        
    }

	public function error( $message ) {

		wp_send_json_error(
			[
				'response' => 'ERROR',
				'message'  => $message,
			]
		);

	}


	public function remove_image( $image_message ) {

		unlink( $_FILES['uploader_custom']['tmp_name'] );

		$this->error( $image_message );;
	}
}