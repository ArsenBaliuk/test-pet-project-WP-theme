</main>
    <footer>
        <div class="ab-container">
            <div class="row">
                <div class="pages-block col-md-6 col-12">
                    <div class="explore-list-pages list-pages">
                        <?php
                        wp_nav_menu( array(
                                'theme_location' => 'footerMenu',
                                'container_class' => '',
                                'container' => '',
                                'menu_class' => 'nav-list',
                            )
                        ); ?>
                    </div>
                </div>
            </div>
        </div>
    </footer>

<?php wp_footer(); ?>

</body>

</html>